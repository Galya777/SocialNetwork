var hierarchy =
[
    [ "Commands", "class_commands.html", null ],
    [ "Comment", "class_comment.html", null ],
    [ "Question", "class_question.html", null ],
    [ "Theme", "class_theme.html", null ],
    [ "User", "class_user.html", [
      [ "Admin", "class_admin.html", null ]
    ] ]
];