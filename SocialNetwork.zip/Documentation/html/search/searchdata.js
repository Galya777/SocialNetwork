var indexSectionsWithContent =
{
  0: "acqtu",
  1: "acqtu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes"
};

