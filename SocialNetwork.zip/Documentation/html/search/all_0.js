var searchData=
[
  ['admin_0',['Admin',['../class_admin.html',1,'']]]
];
